document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const itemsContainer = document.getElementById('itemsContainer');
    const itemCards = document.querySelectorAll('.item-card');

    if (searchInput && searchButton) {
        searchButton.addEventListener('click', filterItems);
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                filterItems();
            }
        });
    }

    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    if (filterButtons) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.dataset.filter;
                filterItems(filter);
                
                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    }

    // Request button functionality
    const requestButtons = document.querySelectorAll('.request-btn');
    if (requestButtons) {
        requestButtons.forEach(button => {
            button.addEventListener('click', function() {
                const itemId = this.dataset.itemId;
                sendRequest(itemId);
            });
        });
    }

    function filterItems(filter = 'all') {
        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        
        itemCards.forEach(card => {
            const title = card.querySelector('.card-title').textContent.toLowerCase();
            const description = card.querySelector('.card-text').textContent.toLowerCase();
            const type = card.dataset.type;
            
            const matchesSearch = title.includes(searchTerm) || description.includes(searchTerm);
            const matchesFilter = filter === 'all' || type === filter;
            
            if (matchesSearch && matchesFilter) {
                card.style.display = 'block';
                card.classList.add('fade-in');
            } else {
                card.style.display = 'none';
            }
        });
    }

    async function sendRequest(itemId) {
        try {
            const response = await fetch('/api/requests', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ item_id: itemId })
            });

            if (response.ok) {
                alert('Request sent successfully!');
                // Update UI to show request sent
                const button = document.querySelector(`[data-item-id="${itemId}"]`);
                if (button) {
                    button.disabled = true;
                    button.textContent = 'Request Sent';
                }
            } else {
                throw new Error('Failed to send request');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to send request. Please try again.');
        }
    }

    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
    });
}); 